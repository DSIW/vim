vjde
====

Mirror of [the vjde script on vim.org](http://www.vim.org/scripts/script.php?script_id=1213).
